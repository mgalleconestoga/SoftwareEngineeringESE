/* Connector/C++ test example program */ 

// Includes required (headers located in /usr/include) 
 #include <stdlib.h>
 #include <iostream>
 #include <mysql_connection.h>
 #include <cppconn/driver.h>
 #include <cppconn/exception.h>
 #include <cppconn/resultset.h>
 #include <cppconn/statement.h>
 #include <cppconn/prepared_statement.h>
 
 using namespace std; 
 
 int main(void) {	
	sql::Driver *driver; 		// Create a pointer to a MySQL driver object
	sql::Connection *con; 		// Create a pointer to a database connection object
	sql::Statement *stmt;		// Crealte a pointer to a Statement object to hold statements 
	sql::ResultSet *res;		// Create a pointer to a ResultSet object to hold results 
	sql::PreparedStatement *pstmt; // Create a pointer to a prepared statement
	int floorNum;					// Floor number 
	
	
	// Create a connection 
	driver = get_driver_instance();
	con = driver->connect("tcp://127.0.0.1:3306", "ese", "ese");	// Note: User and password can not be root and ""
	con->setSchema("elevator");		// MySQL database to connect to 
	
	// Query database
	// ***************************** 
	stmt = con->createStatement();
	res = stmt->executeQuery("SELECT currentFloor FROM elevatorNetwork WHERE nodeID = 1");	// message query
	while(res->next()){
		cout<< "The elevator is currently on Floor: ";
		cout<< res->getInt("currentFloor")<<endl;
	}
	cout<<"\nWhich floor would you like the elevator to go to?: ";
	cin>> floorNum; 
	cout<<endl;
	
	// Update database
	// *****************************
	//stmt->execute("UPDATE elevatorNetwork SET currentFloor = 6 WHERE nodeID = 1"); // Sample static statement
	pstmt = con->prepareStatement("UPDATE elevatorNetwork SET currentFloor = ? WHERE nodeID = 1");
	//pstmt->setString(1, "4");			// first number corresponds to the first '?' (there may be more than 1 '?' so  a 2 would refer to second ? and so on
	pstmt->setInt(1, floorNum);
	pstmt->executeUpdate();
	
	
	// Query database again to confirm update
	// ***************************** 
	stmt = con->createStatement();
	res = stmt->executeQuery("SELECT currentFloor FROM elevatorNetwork WHERE nodeID = 1");	// message query
	while(res->next()){
		cout<< "Elevator moved to floor: ";
		cout<< res->getInt("currentFloor")<<endl;
	}
	
	
	// Clean up pointers 
	delete res;
	delete pstmt;
	delete stmt;
	delete con;
	
	return 0;
}  
