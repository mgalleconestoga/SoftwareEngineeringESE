#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <unistd.h> 
#include <signal.h>
#include <string.h>
#include <stdlib.h>  
#include <fcntl.h>    					// O_RDWR
#include <unistd.h>
#include <ctype.h>
#include <libpcan.h>   					// PCAN library


// Defines
// ***********************************************************************************************************
#define PCAN_RECEIVE_QUEUE_EMPTY        0x00020U  	// Receive queue is empty
#define PCAN_NO_ERROR               	0x00000U  	// No error 

// Elevator project specific 
#define ID_SC_TO_EC  0x100	// ID for messages from Supervisory controller to elevator controller
#define ID_EC_TO_ALL 0x101	// ID for messages from Elevator controller to all other nodes
#define ID_CC_TO_SC  0x200	// ID for messages from Car controller to supervisory controller 
#define ID_F1_TO_SC  0x201	// ID for messages from floor 1 controller to supervisory controller
#define ID_F2_TO_SC  0x202	// ID for messages from floor 2 controller to supervisory controller
#define ID_F3_TO_SC  0x203	// ID for messages from floor 3 controller to supervisory controller	

#define GO_TO_FLOOR1 0x05	// Go to floor 1
#define GO_TO_FLOOR2 0x06	// Go to floor 2
#define GO_TO_FLOOR3 0x07	// Go to floor 3


// Globals
// ***********************************************************************************************************
HANDLE h;
HANDLE h2;
TPCANMsg Txmsg;
TPCANMsg Rxmsg;
DWORD status;

// Code
// ***********************************************************************************************************

// Functions
// *****************************************************************
int pcanTx(int id, int data){
	h = LINUX_CAN_Open("/dev/pcanusb32", O_RDWR);		// Open PCAN channel

	// Initialize an opened CAN 2.0 channel with a 125kbps bitrate, accepting standard frames
	status = CAN_Init(h, CAN_BAUD_125K, CAN_INIT_TYPE_ST);

	// Clear the channel - new - Must clear the channel before Tx/Rx
	status = CAN_Status(h);

	// Set up message
	Txmsg.ID = id; 	
	Txmsg.MSGTYPE = MSGTYPE_STANDARD; 
	Txmsg.LEN = 1; 
	Txmsg.DATA[0] = data; 

	sleep(1);  
	status = CAN_Write(h, &Txmsg);

	// Close CAN 2.0 channel and exit	
	CAN_Close(h);
}

int pcanRx(int num_msgs){
	int i = 0;

	// Open a CAN channel 
	h2 = LINUX_CAN_Open("/dev/pcanusb32", O_RDWR);

	// Initialize an opened CAN 2.0 channel with a 125kbps bitrate, accepting standard frames
	status = CAN_Init(h2, CAN_BAUD_125K, CAN_INIT_TYPE_ST);

	// Clear the channel - new - Must clear the channel before Tx/Rx
	status = CAN_Status(h2);

	// Clear screen to show received messages
	system("@cls||clear");

	// receive CAN message  - CODE adapted from PCAN BASIC C++ examples pcanread.cpp
	printf("\nReady to receive message(s) over CAN bus\n");
	
	// Read 'num' messages on the CAN bus
	while(i < num_msgs) {
		while((status = CAN_Read(h2, &Rxmsg)) == PCAN_RECEIVE_QUEUE_EMPTY){
			sleep(1);
		}
		if(status != PCAN_NO_ERROR) {						// If there is an error, display the code
			printf("Error 0x%x\n", (int)status);
			//break;
		}
										
		if(Rxmsg.ID != 0x01 && Rxmsg.LEN != 0x04) {		// Ignore status message on bus	
			printf("  - R ID:%4x LEN:%1x DATA:%02x \n",	// Display the CAN message
				(int)Rxmsg.ID, 
				(int)Rxmsg.LEN,
				(int)Rxmsg.DATA[0]);
		i++;
		}
	}

	// Close CAN 2.0 channel and exit	
	CAN_Close(h2);
	//printf("\nEnd Rx\n");
}

int menu(){
	
	int usrchoice = 0;
	
	system("@cls||clear");
	while(1) {
		printf("\n\nMenu - Transmit/Receive CAN Messages\n");
		printf("1. Transmit CAN message\n");
		printf("2. Receive CAN message(s)\n");
		printf("3. Exit program\n");
		printf("\nYour choice: ");
		scanf("%d", &usrchoice);

		if (usrchoice >=1 && usrchoice <= 3) {	
			return usrchoice;
		} else {
			printf("\nPLEASE SELECT FROM CHOICES 1-3 ONLY!\n\n");
			sleep(3);
			system("@cls||clear");
		}
	}
	
}


int chooseID(){

	int IdChoice = 0;		// Menu item number
	int IDvalue = 0 ;		// ID value in HEX
	while(1) {
		system("@cls||clear");
		printf("\nChoose sender and receiver for message\n");
		printf("1. Message from Supervisory controller (i.e. this node) to all other nodes\n");
		printf("2. Message from Elevator controller to all other nodes\n");
		printf("3. Message from Car controller to supervisory controller (this node)\n");
		printf("4. Message from floor 1 controller to supervisory controller (this node)\n");
		printf("5. Message from floor 2 controller to supervisory controller (this node)\n");
		printf("6. Message from floor 3 controller to supervisory controller (this node)\n");

		printf("\nYour choice: ");
		scanf("%d", &IdChoice);

		if (IdChoice >=1 && IdChoice <= 6) {	
			switch(IdChoice) {
				case 1:
					IDvalue = ID_SC_TO_EC; 
					return(IDvalue);
				case 2:
					IDvalue = ID_EC_TO_ALL; 
					return(IDvalue);
				case 3:
					IDvalue = ID_CC_TO_SC; 
					return(IDvalue);
				case 4:
					IDvalue = ID_F1_TO_SC; 
					return(IDvalue);
				case 5:
					IDvalue = ID_F2_TO_SC; 
					return(IDvalue);
				case 6:
					IDvalue = ID_F3_TO_SC; 
					return(IDvalue);
			}

		} else {
			printf("\nPLEASE SELECT FROM CHOICES 1-6 ONLY!\n\n");
			sleep(3);
		}

	}
}

int chooseMsg(){
	int messageChoice = 0; 
	int messageValue = 0;
	
	while(1) {
		system("@cls||clear");
		printf("\nChoose Message\n");
		printf("1. Go to floor 1\n");
		printf("2. Go to floor 2\n");
		printf("3. Go to floor 3\n");
		printf("\nYour choice: ");
		scanf("%d", &messageChoice);

		if (messageChoice >=1 && messageChoice <= 3) {	
			switch(messageChoice) {
				case 1:
					messageValue = GO_TO_FLOOR1; 
					return(messageValue);
					break;
				case 2:
					messageValue = GO_TO_FLOOR2; 
					return(messageValue);
					break;
				case 3:
					messageValue = GO_TO_FLOOR3; 
					return(messageValue);
					break;
			}

		} else {
			printf("PLEASE SELECT FROM CHOICES 1-3 ONLY!\n\n");
			sleep(3);
		}
	}
}


// ******************************************************************

int main() {

	int choice; 
	int ID; 
	int data; 
	int numRx;

	while(1) {
		system("@cls||clear");
		choice = menu(); 
		switch (choice) {
			case 1: 
				ID = chooseID();		// user to select ID depending on intended recipient
				data = chooseMsg();		// user to select message data
				pcanTx(ID, data);		// transmit ID and data 
				break; 
			case 2:
				printf("\nHow many messages to receive? ");
				scanf("%d", &numRx);
				pcanRx(numRx);
				break;
			case 3: 
				return(0);
			
			default:
				printf("Error on input values");
				sleep(3);
				break;
		}
		sleep(1);					// delay between send/receive
	}
}
